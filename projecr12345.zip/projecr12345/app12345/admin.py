from django.contrib import admin
from app12345.models import Actor
from app12345.models import UserProfile



admin.site.register(UserProfile)
admin.site.register(Actor)

