from django.apps import AppConfig


class App12345Config(AppConfig):
    name = 'app12345'
